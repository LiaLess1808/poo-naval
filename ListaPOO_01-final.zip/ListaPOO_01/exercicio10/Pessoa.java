package exercicio10;

public class Pessoa 
{
    //---------------------------------------------FERRAMENTAS-----------------------------------------------



    //----------------------------------------------ATRIBUTOS------------------------------------------------

        private String nome;
        private Pessoa pai;
        private Pessoa mãe;

    //--------------------------------------------CONSTRUTORES-----------------------------------------------

        public Pessoa() 
        {
            
        }
        public Pessoa(String nome, Pessoa pai, Pessoa mãe)
        {
            this.nome = nome;

            this.pai = pai;
            this.mãe = mãe;
        }

    //-----------------------------------------------MÉTODOS-------------------------------------------------



    //-----------------------------------------GETTER's E SETTER's-------------------------------------------

        public String getNome() 
        {
            return nome;
        }
        public Pessoa getPai() 
        {
            return pai;
        }
        public Pessoa getMãe() 
        {
            return mãe;
        }
        
        public void setNome(String nome) 
        {
            this.nome = nome;
        } 
        public void setPai(Pessoa pai) 
        {
            this.pai = pai;
        }  
        public void setMãe(Pessoa mãe) 
        {
            this.mãe = mãe;
        }

    //--------------------------------------------SOBRESCRIÇÕES----------------------------------------------
    
}

