package exercicio10;

import java.util.Scanner;

public class Principal
{
    public static void main(String args[])
    {
        Scanner reader = new Scanner(System.in);

        Pessoa usuário = new Pessoa(" ", null, null);
        
        Pessoa mãe = new Pessoa(" ", null, null);
        Pessoa avóMãe = new Pessoa(" ", null, null);
        Pessoa avôMãe = new Pessoa(" ", null, null);

        Pessoa pai = new Pessoa(" ", null, null);
        Pessoa avóPai = new Pessoa(" ", null, null);
        Pessoa avôPai = new Pessoa(" ", null, null);

        System.out.print(" Digite seu nome: ");
            usuário.setNome(reader.nextLine());
                System.out.println();

                System.out.print("Digite o nome da sua mãe: ");
                    usuário.setMãe(mãe);
                        mãe.setNome(reader.nextLine());
                    System.out.println();

                        System.out.print("Digite o nome da sua avó materna: ");
                            usuário.getMãe().setMãe(avóMãe);
                                avóMãe.setNome(reader.nextLine());
                            System.out.println();

                        System.out.print("Digite o nome do seu avô materno: ");
                            usuário.getMãe().setPai(avôMãe);
                                avôMãe.setNome(reader.nextLine());
                            System.out.println();


                System.out.print("Digite o nome do seu pai: ");
                    usuário.setPai(pai);
                        pai.setNome(reader.nextLine());
                     System.out.println();

                        System.out.print("Digite o nome da sua avó paterna: ");
                            usuário.getPai().setMãe(avóPai);
                                avóPai.setNome(reader.nextLine());
                            System.out.println();

                        System.out.print("Digite o nome do seu avô paterno: ");
                            usuário.getPai().setPai(avôPai);
                                avôPai.setNome(reader.nextLine());
                            System.out.println();
        System.out.println();
        System.out.println("========================================================================================================================");
        System.out.println("[                                                Sua árvore genealógica                                                ]");
        System.out.print("[ " + avóMãe.getNome() + " ] [ " + avôMãe.getNome() + " ]");
        System.out.print("\t\t");
        System.out.print("[ " + avóPai.getNome() + " ] [ " + avôPai.getNome() + " ]");
        System.out.println();

        System.out.println("    [ " + mãe.getNome() + " ]\t\t [ " + pai.getNome() + " ]");

        System.out.println("\t\t[ " + usuário.getNome() + " ]");
            
        reader.close();

    } 
}
