package exercicio2;

public class Principal 
{
    public static void main(String args[])
    {
        Pessoa Albert = new Pessoa("Albert Einstein", 14, 3, 1879);
        Pessoa Isaac = new Pessoa("Isaac Newton",4, 1, 1643);

        System.out.println(Albert.toString());
        System.out.println(Isaac.toString());
            System.out.println();
    }
}
