package exercicio3;

import java.util.Calendar;

public class Pessoa
{
    //---------------------------------------------FERRAMENTAS-----------------------------------------------

        private Calendar dataAtual = Calendar.getInstance();
        private int anoAtual = dataAtual.get(Calendar.YEAR);
        private int mesAtual = dataAtual.get(Calendar.MONTH);
        private int diaAtual = dataAtual.get(Calendar.DAY_OF_MONTH);

    //----------------------------------------------ATRIBUTOS------------------------------------------------
    
        private String nome;
        private int idade;

        private int diaDoNascimento;
        private int mesDoNascimento;
        private int anoDoNascimento;

        private Universidade uni;
        private String dept;
    //--------------------------------------------CONSTRUTORES-----------------------------------------------
   
        public Pessoa() 
        {
        }
        public Pessoa(String nome, String dept, Universidade uni)
        {
            this.nome = nome;
            this.dept = dept;
            this.uni = uni;
        }
        public Pessoa(String nome, int diaDoNascimento, int mesDoNascimento, int anoDoNascimento,String dept, Universidade uni) 
        {
            this.nome = nome;
            
            this.diaDoNascimento = diaDoNascimento;
            this.mesDoNascimento = mesDoNascimento;
            this.anoDoNascimento = anoDoNascimento;
            
            calculaIdade(diaDoNascimento, mesDoNascimento, anoDoNascimento);

            this.dept = dept;
            this.uni = uni;
        }

    //-----------------------------------------------MÉTODOS-------------------------------------------------
     
        private int calculaIdade(int diaDoNascimento, int mesDoNascimento, int anoDoNascimento)
        {
            int idadeCalc = anoAtual - anoDoNascimento;
            this.idade = idadeCalc;

            if(diaDoNascimento < 1 || diaDoNascimento > 31 || mesDoNascimento < 1 || mesDoNascimento > 12|| anoDoNascimento > anoAtual)
            {
                System.out.println("Data inválida, tente novamente.");
                if(diaDoNascimento<1 || diaDoNascimento>31)
                {
                    switch(this.mesDoNascimento)
                    {
                        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                        {
                            if(diaDoNascimento>31)
                            {
                                this.diaDoNascimento = 0;
                                {
                                    System.out.println("Este mês tem até 31 dias. Digite um valor de 1 a 31.");
                                }
                            }
                        }
                        break;
                        case 2:
                        {
                            if(diaDoNascimento>28)
                            {
                                this.diaDoNascimento = 0;
                                {
                                    System.out.println("Este mês tem até 28 dias. Digite um valor de 1 a 28.");
                                }
                            }
                        }
                        break;

                        case 4: case 6: case 9: case 11:
                        {
                            if(diaDoNascimento>30)
                            {
                                this.diaDoNascimento = 0;
                                {
                                    System.out.println("Este mês tem até 30 dias. Digite um valor de 1 a 30.");
                                }
                            }
                        }
                        break;
                    }
                    System.out.println("O dia deve ser maior ou igual a um e menor ou igual a 31.");
                }
                if(mesDoNascimento < 1 || mesDoNascimento > 12)
                {
                    System.out.println("Digite um valor de 1 a 12.");
                }
                if(anoAtual < anoDoNascimento)
                {
                    System.out.println("Digite um valor de ano de nascimento menor que o valor do ano atual.");
                }
                this.idade = 0;
            }
            else
            {
                if((mesAtual<mesDoNascimento) || (mesAtual == mesDoNascimento) && ((diaAtual<diaDoNascimento)))
                {
                    this.idade = idadeCalc - 1;
                } 
            }
            return idade;
        }
        public int informaIdade()
        {
            return idade;
        }
        public String informaNome()
        {
            return nome;
        }

    //-----------------------------------------GETTER's E SETTER's-------------------------------------------
    
        public String getNome() 
        {
            return nome;
        }
        public int getDiaDoNascimento() 
        {
            return diaDoNascimento;
        }
        public int getMesDoNascimento() 
        {
            return mesDoNascimento;
        }
        public int getAnoDoNascimento() 
        {
            return anoDoNascimento;
        }
        public Universidade getUni() 
        {
            return uni;
        }
        public String getDept() {
            return dept;
        }
        
        public void setNome(String nome) 
        {
            this.nome = nome;
        } 
        public void setDiaDoNascimento(int diaDoNascimento) 
        {
            if(diaDoNascimento<1||diaDoNascimento>31)
            {
                this.diaDoNascimento = 0;
                System.out.println("Dia inválido. Valor atual do dia de nascimento: 0");
                switch(this.mesDoNascimento)
                {
                    case 2:
                    {
                        if(diaDoNascimento>28)
                        {
                            this.diaDoNascimento = 0;
                            {
                                System.out.println("Dia inválido. Valor atual do dia de nascimento: 0");
                            }
                        }
                    }
                    break;
                    case 4: case 6: case 9: case 11:
                    {
                        if(diaDoNascimento>30)
                        {
                            this.diaDoNascimento = 0;
                            {
                                System.out.println("Dia inválido. Valor atual do dia de nascimento: 0");
                            }
                        }
                    }
                    break;
                    
                }
            }
            this.diaDoNascimento = diaDoNascimento;
        }
        public void setMesDoNascimento(int mesDoNascimento) 
        {
            if(mesDoNascimento<1||mesDoNascimento>12)
            {
                this.mesDoNascimento = 0;
                System.out.println("Mês inválido. Valor atual do mês de nascimento: 0");
            }
            this.mesDoNascimento = mesDoNascimento;
        }
        public void setAnoDoNascimento(int anoDoNascimento) 
        {
            if(anoDoNascimento>anoAtual)
            {
                this.anoDoNascimento = 0;
                System.out.println("Ano inválido. Valor atual do ano de nascimento: 0");
            }
            this.anoDoNascimento = anoDoNascimento;
        }
        public void setUni(Universidade uni) 
        {
            this.uni = uni;
        }
        public void setDept(String dept) 
        {
            this.dept = dept;
        }
    
    //--------------------------------------------SOBRESCRIÇÕES----------------------------------------------

        @Override
        public String toString()
        {
            return "- " + getNome().split(" ")[1] + " trabalhou como professor de " + getDept().toLowerCase() +" em " + uni.getNome() + " ( " + uni.getPais() + " ).";
        }

    }