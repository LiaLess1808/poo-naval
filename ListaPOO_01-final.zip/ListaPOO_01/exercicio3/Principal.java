package exercicio3;

public class Principal 
{
    public static void main(String args[])
    {
        Universidade Princeton = new Universidade("Princeton", "Nova Jersey - Estados Unidos da América");
        Universidade Cambridge = new Universidade("Cambridge", "Inglaterra");

        Pessoa Albert = new Pessoa("Albert Einstein", "Física", Princeton);
        Pessoa Isaac = new Pessoa("Isaac Newton","Matemática", Cambridge);

        System.out.println(Albert.toString());
        System.out.println(Isaac.toString());
            System.out.println();
    }
}
