package exercicio3;

public class Universidade 
{
    //----------------------------------------------ATRIBUTOS------------------------------------------------

        private String nome;
        private String pais;
    
    //--------------------------------------------CONSTRUTORES-----------------------------------------------

        public Universidade() 
        {
        }
        public Universidade(String nome, String pais)
        {
            this.nome = nome;
            this.pais = pais;

        }
        
    //-----------------------------------------------MÉTODOS-------------------------------------------------
   

    //-----------------------------------------GETTER's E SETTER's-------------------------------------------

        public String getNome() 
        {
            return nome;
        } 
        public String getPais() 
        {
            return pais;
        } 
        
        public void setNome(String nome) 
        {
            this.nome = nome;
        }
        public void setPais(String pais) 
        {
            this.pais = pais;
        }

    //--------------------------------------------SOBRESCRIÇÕES----------------------------------------------
    
}
