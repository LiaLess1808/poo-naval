package exercicio4;

public class Departamento
{
    //----------------------------------------------ATRIBUTOS------------------------------------------------

        private int codDept;
        private String nome;

    //--------------------------------------------CONSTRUTORES-----------------------------------------------

        public Departamento() 
        {
        }
        public Departamento(int codDept, String nome) 
        {
            this.codDept = codDept;
            this.nome = nome;
        }

    //-----------------------------------------------MÉTODOS-------------------------------------------------



    //-----------------------------------------GETTER's E SETTER's-------------------------------------------

        public int getCodDept() 
        {
            return codDept;
        }
        public String getNome() 
        {
            return nome;
        }

        public void setCodDept(int codDept) 
        {
            this.codDept = codDept;
        }
        public void setNome(String nome) 
        {
            this.nome = nome;
        }

    //--------------------------------------------SOBRESCRIÇÕES----------------------------------------------

}
