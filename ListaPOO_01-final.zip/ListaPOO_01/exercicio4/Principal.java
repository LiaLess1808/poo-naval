package exercicio4;

public class Principal 
{
    public static void main(String args[])
    {
        Departamento Física = new Departamento(0, "Física");
        Departamento Matemática = new Departamento(1, "Matemática");

        Universidade Princeton = new Universidade("Princeton", "Nova Jersey - Estados Unidos", Física);
        Universidade Cambridge = new Universidade("Cambridge", "Inglaterra", Matemática);

        Pessoa Einstein = new Pessoa("Albert Einstein", Física, Princeton);
        Pessoa Newton = new Pessoa("Isaac Newton", Matemática, Cambridge);

        System.out.println(Einstein.toString());
        System.out.println(Newton.toString());
        System.out.println();
    }
}
