package exercicio4;

public class Universidade 
{
    //----------------------------------------------ATRIBUTOS------------------------------------------------

    private String nome;
    private String pais;
    private Departamento dept;
    //--------------------------------------------CONSTRUTORES-----------------------------------------------

    public Universidade() 
    {
    }
    public Universidade(String nome, String pais, Departamento dept)
    {
        
        this.nome = nome;
        this.pais = pais;
        this.dept = dept;

    }
    
    //-----------------------------------------------MÉTODOS-------------------------------------------------
   

    //-----------------------------------------GETTER's E SETTER's-------------------------------------------

    public String getNome() 
    {
        return nome;
    } 
    public String getPais() 
    {
        return pais;
    } 
    public Departamento getDept() 
    {
        return dept;
    }

    public void setNome(String nome) 
    {
        this.nome = nome;
    }
    public void setPais(String pais) 
    {
        this.pais = pais;
    }
   
    public void setDept(Departamento dept) 
    {
        this.dept = dept;
    }

    //--------------------------------------------SOBRESCRIÇÕES----------------------------------------------
    
}