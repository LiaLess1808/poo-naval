package exercicio5;

public class Principal 
{
    public static void main(String args[])
    {
        Departamento depts_Princeton[]  = new Departamento[50];
                     depts_Princeton[0] = new Departamento(0, "Física");
                     depts_Princeton[1] = new Departamento(1, "Engenharia");
                     depts_Princeton[2] = new Departamento(2, "Matemática");

        Departamento depts_Cambridge[]  = new Departamento[50];
                     depts_Cambridge[0] = new Departamento(0, "Matemática");
                     depts_Princeton[1] = new Departamento(1, "Línguas");
                     depts_Princeton[2] = new Departamento(2, "Música");

        Universidade Princeton = new Universidade("Princeton", "Nova Jersey - Estados Unidos", depts_Princeton);
        Universidade Cambridge = new Universidade("Cambridge", "Inglaterra", depts_Cambridge);

        Pessoa Einstein = new Pessoa("Albert Einstein", depts_Princeton[0], Princeton);
        Pessoa Newton = new Pessoa("Isaac Newton", depts_Cambridge[0], Cambridge);

        System.out.println(Einstein.toString());
        System.out.println(Newton.toString());
            System.out.println();
    }
}