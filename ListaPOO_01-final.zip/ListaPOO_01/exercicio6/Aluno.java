package exercicio6;

public class Aluno 
{
    //---------------------------------------------FERRAMENTAS-----------------------------------------------

        public final double nota60 = 60.00;
        public final double nota40 = 40.00;

    //----------------------------------------------ATRIBUTOS------------------------------------------------

        private String nome;
        private double notaParcial1, notaParcial2;
            private double media;
        private int matricula;

        private String resultado;
        
        
    //--------------------------------------------CONSTRUTORES-----------------------------------------------

        public Aluno() 
        {
        }
        public Aluno(String nome,int matricula,  int notaParcial1, int notaParcial2) 
        {
            this.nome = nome;
            this.notaParcial1 = notaParcial1;
            this.notaParcial2 = notaParcial2;
        }
        
        
    //-----------------------------------------------MÉTODOS-------------------------------------------------

        private void calculaMedia(double notaParcial1, double notaParcial2)
        {
            double media = (notaParcial1 + notaParcial2)/2;
            this.media = media;
        }
        private String resultadoFinal(double media)
        {
            String state = " ";

            if(media < nota40)
            {
                state = "REPROVADO";
            }
            else
            {
                if(media<nota60)
                {
                    state = "DE RECUPERAÇÃO";

                }
                else
                {
                    if(media>nota60)
                    {
                        state = "APROVADO";
                      
                    }
                    
                }
            }
            return state;
        }
        
    //-----------------------------------------GETTER's E SETTER's-------------------------------------------

        public String getNome() 
        {
            return nome;
        }
        public int getMatricula() 
        {
            return matricula;
        }
        public double getNotaParcial1() 
        {
            return notaParcial1;
        }
        public double getNotaParcial2() 
        {
            return notaParcial2;
        }
        public double getMedia()
        {
            return media;
        }
        public String getResultado()
        {
            return resultado;
        }
        
        public void setNome(String nome) 
        {
            this.nome = nome;
        }
        public void setMatricula(int matricula) 
        {
            this.matricula = matricula;
        }
        public void setNotaParcial1(double notaParcial1) 
        {
            if(notaParcial1 < 0 || notaParcial1 > 100)
            {
                System.out.println("Erro. Nota 1 atual: \'0\'.");
                this.notaParcial1 = 0;
            }
            else
            {
                this.notaParcial1 = notaParcial1;
            }
        
        }
        public void setNotaParcial2(double notaParcial2) 
        {
            if(notaParcial2 < 0 || notaParcial2 > 100)
            {
                System.out.println("Erro. Nota 2 atual: \'0\'.");
                this.notaParcial2 = 0;
            }
            else
            {
                this.notaParcial2 = notaParcial2;
            }
        }
        public void setMedia(double notaParcial1, double notaParcial2)
        {
            calculaMedia(notaParcial1, notaParcial2);
        }
        public void setResultado(double media)
        {
            this.resultado = resultadoFinal(media);
        }
    //--------------------------------------------SOBRESCRIÇÕES----------------------------------------------
        
        
}
