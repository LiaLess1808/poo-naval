package exercicio6;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.text.DecimalFormat;

public class Principal 
{
    private static final DecimalFormat dfd = new DecimalFormat("0.00");
    private static final DecimalFormat dfh = new DecimalFormat( "0.0");

    public static void main(String args[])
    {
        Scanner reader = new Scanner(System.in);

        Aluno aluno;

        List<Aluno> Turma = new ArrayList<Aluno>();
        double mediaDaTurma = 0;
        int alunosAprovados = 0, alunosDeRecuperação = 0, alunosReprovados = 0, alunosAbaixoDaMédia = 0;
        String opção = " ";
    
        do 
        {
            System.out.println("========================================================================================================================");
            System.out.println("[                                         Escolha uma das opções abaixo                                                ]");
            System.out.println("------------------------------------------------------------------------------------------------------------------------");
            System.out.println("[                                            SIGN - Cadastra alunos                                                    ]");
            System.out.println("[                                      PRNT - Imprime resultados da turma                                              ]");
            System.out.println("[                                           FIM  - Sair do programa                                                    ]");
            System.out.println("========================================================================================================================");

            System.out.print("        Digite aqui sua opção: ");
            opção = reader.nextLine();

            if(opção.toLowerCase().equals("sign"))
            {
                    aluno = new Aluno();

                    System.out.print("               Digite o nome: ");
                        aluno.setNome(reader.nextLine());
                    System.out.print("               Digite a matrícula: ");
                        aluno.setMatricula(reader.nextInt());
                    System.out.println();

                    System.out.print("               Digite sua primeira nota parcial: ");
                        aluno.setNotaParcial1(reader.nextDouble());
                    System.out.print("               Digite sua segunda nota parcial: ");
                        aluno.setNotaParcial2(reader.nextDouble());
                    System.out.println();

                    aluno.setMedia(aluno.getNotaParcial1(), aluno.getNotaParcial2());
                    aluno.setResultado(aluno.getMedia());

                    Turma.add(aluno);
                    reader.nextLine();
            }
            else 
            {
                if(opção.toLowerCase().equals("prnt"))
                {
                    if(Turma.isEmpty())
                    {
                        
                        System.out.println("       [                                 Não existem alunos cadastrados!                                      ]");
                        System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
                        reader.nextLine();
                    }
                    else
                    {
                        //Definir media da turma
                            for(int l = 0; l < Turma.size(); l++)
                            {
                                mediaDaTurma += Turma.get(l).getMedia();
                            }
                            mediaDaTurma = mediaDaTurma/Turma.size();
                        //Definir numero de alunos aprovados
                            for(int l = 0; l < Turma.size(); l++)
                            {
                                if(Turma.get(l).getResultado().toLowerCase().equals("aprovado"))
                                {
                                    alunosAprovados++;
                                }
                            }
                        //Definir numero de alunos de recuperacao
                            for(int l = 0; l<Turma.size(); l++)
                            {
                                if(Turma.get(l).getResultado().toLowerCase().equals("de recuperação"))
                                {
                                    alunosDeRecuperação++;
                                }
                            }
                        //Definir numero de alunos reprovados
                            for(int l = 0; l < Turma.size(); l++)
                            {
                                if(Turma.get(l).getResultado().toLowerCase().equals("reprovado"))
                                {
                                    alunosReprovados++;
                                }
                            }
                        //Imprimir cálculos
                            System.out.println("[       Média da Turma       |       Qtd. Aprovados       |       Qtd. Recuperação       |       Qtd. Reprovados       ]");
                            if(mediaDaTurma < 100)
                            {
                                System.out.println("[       " + dfd.format(mediaDaTurma) + "       |       " + alunosAprovados + "       |       " + alunosDeRecuperação + "       |       " + alunosReprovados + "       ]");
                            }
                            else
                            {
                                System.out.println("[       " + dfh.format(mediaDaTurma) + "       |       " + alunosAprovados + "       |       " + alunosDeRecuperação + "       |       " + alunosReprovados + "       ]");
                            }
                            
                        //Definir alunos que ficaram abaixo da média da turma
                        System.out.println("[                             Matrículas de alunos que ficaram abaixo da média da turma                                ]");
                        for(int l = 0; l < Turma.size(); l++)
                        {
                            if(Turma.get(l).getMedia() < mediaDaTurma)
                            {
                                alunosAbaixoDaMédia++;
                            }
                        }
                        if(alunosAbaixoDaMédia>0)
                        {
                            for(int l = 0; l < Turma.size(); l++)
                            {
                                if(Turma.get(l).getMedia() < mediaDaTurma)
                                {   
                                    System.out.println("\t\t\t[\t\t\t" + Turma.get(l).getMatricula() + "\t\t\t]\t");
                                }
                            }
                            System.out.println();
                        }
                        else
                        {
                            System.out.println("       [                                 Não existem alunos abaixo da média.                                  ]");
                        }

                        System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
                        reader.nextLine();
                    }         
                }
                else
                {
                    System.out.println();
                }
            }
        } while (!opção.equalsIgnoreCase("fim"));
        System.out.println("       [                                             Saindo...                                                ]");

        reader.close();
    }
}
