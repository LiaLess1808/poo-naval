package exercicio7;

import java.util.ArrayList;
import java.util.List;

public class Pedido 
{
    //---------------------------------------------FERRAMENTAS-----------------------------------------------
    
    //----------------------------------------------ATRIBUTOS------------------------------------------------
        
        private int quantidadeDeItens;
        private List<Produto> itens = new ArrayList<Produto>();
        private String tipoDePagamento;

    //--------------------------------------------CONSTRUTORES-----------------------------------------------

    public Pedido() 
    {
    }
    public Pedido(List<Produto> itens, int quantidadeDeItens, String tipoDePagamento) 
    {
        this.itens = itens;
        this.quantidadeDeItens = quantidadeDeItens;
        this.tipoDePagamento = tipoDePagamento;
    }
    
    //-----------------------------------------------MÉTODOS-------------------------------------------------

    //-----------------------------------------GETTER's E SETTER's-------------------------------------------

        public List<Produto> getItens() 
        {
            return itens;
        }
        public int getQuantidadeDeItens() 
        {
            return quantidadeDeItens;
        }
        public String getTipoDePagamento() 
        {
            return tipoDePagamento;
        }
        

        public void setItens(List<Produto> itens) 
        {
            this.itens = itens;
        }
        public void setQuantidade(int quantidadeDeItens) 
        {
            if(quantidadeDeItens < 0)
            {
                this.quantidadeDeItens = 0;
            }
            else
            {
                this.quantidadeDeItens = quantidadeDeItens;
            }
            
        }
        public void setTipoDePagamento(String tipoDePagamento) 
        {
            this.tipoDePagamento = tipoDePagamento;
        }
        
    //--------------------------------------------SOBRESCRIÇÕES----------------------------------------------

}
