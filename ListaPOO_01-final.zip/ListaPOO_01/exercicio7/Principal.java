package exercicio7;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.text.DecimalFormat;

public class Principal 
{
    private static final DecimalFormat dfd = new DecimalFormat("0.00");
    
    public static void main(String args[]) 
    {
        Scanner reader = new Scanner(System.in);

        Produto prod;
        List<Produto> Produtos = new ArrayList<Produto>();
        String opçãoProduto = " "; 
        do
        {
            System.out.println("========================================================================================================================");
            System.out.println("[                                         Escolha uma das opções abaixo                                                ]");
            System.out.println("------------------------------------------------------------------------------------------------------------------------");
            System.out.println("[                                            SIGN - Cadastra produtos                                                  ]");
            System.out.println("[                                       PRNT - Imprime produtos no estoque                                             ]");
            System.out.println("[                                            FIM  - Sair do cadastro                                                   ]");
            System.out.println("========================================================================================================================");

            System.out.print("        Digite aqui sua opção: ");
            opçãoProduto = reader.nextLine();

            if(opçãoProduto.toLowerCase().equals("sign"))
            {
                prod = new Produto();

                System.out.print("\t\tDigite o nome do produto: ");
                    prod.setNomeDoProduto(reader.nextLine());
                System.out.println();

                System.out.print("\t\tDigite o preço do produto: R$");
                    prod.setPreço(reader.nextDouble());
                System.out.println();

                System.out.print("\t\tDigite a quantidade em estoque: ");
                    prod.setQuantidadeEmEstoque(reader.nextInt());
                System.out.println();

                Produtos.add(prod);
                reader.nextLine();
            }
            else
            {
                if(opçãoProduto.toLowerCase().equals("prnt"))
                {
                    if(Produtos.isEmpty())
                    {
                        System.out.println("       [                                Não existem produtos cadastrados!                                     ]");
                        System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
                        reader.nextLine();
                    }
                    else
                    {
                        //calculos e impressoes

                        System.out.println("[                                        Produtos cadastrados no sistema                                               ]");
                        for(int l = 0; l < Produtos.size(); l++)
                        {
                            System.out.println("\t[\t"+Produtos.get(l).getNomeDoProduto()+"\t|\t"+ "R$" + dfd.format(Produtos.get(l).getPreço())+"\t|\t"+Produtos.get(l).getQuantidadeEmEstoque()+"\t]");
                        }
                        System.out.println();

                        System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
                        reader.nextLine();
                    }
                }
                else
                {
                    System.out.println();
                }
            }
        }
        while(!opçãoProduto.toLowerCase().equals("fim"));
        System.out.println("       [                                       Produtos cadastrados!                                          ]");
        System.out.println();
        System.out.println();
        /*
        * ==================================================================================================================================================
        * ==================================================================================================================================================
        * ==================================================================================================================================================
        */

        Pedido pedido = new Pedido();
        Produto prodPedido;
        List<Produto> itensPedidos = new ArrayList<Produto>();
        double preçoTotal = 0;
        int quantidadeTotalDeItensPedidos = 0;
        String opçãoPedido = " ";
        int opçãoPagamento = 0;

        do
        {
            System.out.println("========================================================================================================================");
            System.out.println("[                                         Escolha uma das opções abaixo                                                ]");
            System.out.println("------------------------------------------------------------------------------------------------------------------------");
            System.out.println("[                                           1 - Cartão de crédito                                                      ]");
            System.out.println("[                                           2 - Cartão de débito                                                       ]");
            System.out.println("[                                               3 - Dinheiro                                                           ]");
            System.out.println("[                                                4 - Cheque                                                            ]");
            System.out.println("========================================================================================================================");
            System.out.print("        Digite aqui sua opção: ");
                
            opçãoPagamento = reader.nextInt();
            switch(opçãoPagamento)
            {
                case 1:
                {
                    pedido.setTipoDePagamento("Cartão de crédito");
                }
                break;
                case 2:
                {
                    pedido.setTipoDePagamento("Cartão de débito");
                }
                break;
                case 3:
                {
                    pedido.setTipoDePagamento("Dinheiro");
                }
                break;
                case 4:
                {
                    pedido.setTipoDePagamento("Cheque");
                }
                break;
                default: System.out.println("\t\t>> Opção inválida! <<");
                pedido.setTipoDePagamento("Inválido");
            }
            System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
            reader.nextLine();
            reader.nextLine();
        }
        while(pedido.getTipoDePagamento().equalsIgnoreCase("Inválido"));

        do
        {
            System.out.println("========================================================================================================================");
            System.out.println("[                                         Escolha uma das opções abaixo                                                ]");
            System.out.println("------------------------------------------------------------------------------------------------------------------------");
            System.out.println("[                                     SIGN - Adicionar produtos ao carrinho                                            ]");
            System.out.println("[                                       PRNT - Imprime produtos da lista                                               ]");
            System.out.println("[                                            FIM  - Sair do programa                                                   ]");
            System.out.println("========================================================================================================================");

            System.out.print("        Digite aqui sua opção: ");
            
            opçãoPedido=reader.nextLine();
            if(opçãoPedido.toLowerCase().equals("sign"))
            {
                prodPedido = new Produto();

                System.out.print("\t\tInsira o nome do produto: ");
                    prodPedido.setNomeDoProduto(reader.nextLine());
                System.out.println();

                System.out.print("\t\tInsira a quantidade desejada: ");
                    prodPedido.setQuantidadePedida(reader.nextInt());
                System.out.println();

                itensPedidos.add(prodPedido);
                reader.nextLine();
            }
            else
            {
                if(opçãoPedido.toLowerCase().equals("prnt"))
                {
                    if(itensPedidos.isEmpty())
                    {
                        System.out.println("       [                                 Não existem produtos no pedido!                                      ]");
                        System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
                        reader.nextLine();
                    }
                    else
                    {
                        //verifica se os produtos existem no sistema
                        pedido.setItens(itensPedidos);
                        for(int l = 0; l < pedido.getItens().size();l++)
                        {
                            System.out.println("       [                       Verificando existência do produto:"+ pedido.getItens().get(l).getNomeDoProduto()+"...                                 ]");
                                    
                            for(int c = 0; c < Produtos.size(); c++)
                            {
                                if(pedido.getItens().get(l).getNomeDoProduto().equalsIgnoreCase(Produtos.get(c).getNomeDoProduto()))
                                {
                                    System.out.println("       [                                    Produto encontrado.                                     ]");
                                    pedido.getItens().get(l).setExistenciaDoProdutoNoEstoque(true);

                                    System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
                                    reader.nextLine();
                                    break;
                                }
                                else
                                {
                                    if( c == (Produtos.size() - 1))
                                    {
                                        System.out.println("       [                                  Produto não encontrado.                                   ]");
                                        pedido.getItens().get(l).setExistenciaDoProdutoNoEstoque(false);

                                        System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
                                        reader.nextLine();
                                        break;
                                    }
                                    else
                                    {
                                        continue;
                                    }
                                    
                                }    
                            }
                        }

                        //deleta produtos não existentes
                        for(int l = 0; l < pedido.getItens().size(); l++)
                        {
                            if(pedido.getItens().get(l).getExistenciaDoProdutoNoEstoque() == false)
                            {
                                pedido.getItens().remove(pedido.getItens().get(l));
                            }
                            else
                            {
                                continue;
                            }
                        }

                        //atribui o máximo que o cliente pode comprar do produto é a quantidade deste em estoque.
                        for(int l = 0; l < pedido.getItens().size();l++)
                        {
                            for(int c = 0; c< Produtos.size(); c++)
                            {
                                if(pedido.getItens().get(l).getNomeDoProduto().equalsIgnoreCase(Produtos.get(c).getNomeDoProduto()))
                                {
                                    if(pedido.getItens().get(l).getQuantidadePedida() > Produtos.get(c).getQuantidadeEmEstoque())
                                    {
                                        pedido.getItens().get(l).setQuantidadePedida(Produtos.get(c).getQuantidadeEmEstoque());
                                    }
                                    else
                                    {
                                        continue;
                                    }
                                }
                                else
                                {
                                    continue;
                                }
                            }
                        }

                        //atribui o preço do item pedido ao preço do item no estoque
                        for(int l = 0; l < pedido.getItens().size(); l++)
                        {
                           for(int c = 0; c < Produtos.size(); c++)
                           {
                                if(pedido.getItens().get(l).getNomeDoProduto().equalsIgnoreCase(Produtos.get(c).getNomeDoProduto()))
                                {
                                    pedido.getItens().get(l).setPreço(Produtos.get(c).getPreço());
                                }
                                else
                                {
                                    continue;
                                }
                           }
                        }

                        //calcula o preço total
                        for(int l = 0; l < pedido.getItens().size(); l++)
                        {
                            preçoTotal = preçoTotal + (pedido.getItens().get(l).getPreço() * pedido.getItens().get(l).getQuantidadePedida());
                        }
                        //calcula a quantidade total de produtos
                        for(int l = 0; l < pedido.getItens().size(); l++)
                        {
                            quantidadeTotalDeItensPedidos += pedido.getItens().get(l).getQuantidadePedida();
                        }

                        //imprime a lista de produtos no formato   nome  | quantidade | preço do produto
                        //                             ao final    total | qtd. total | preço total | forma de pagamento
                        System.out.println("========================================================================================================================");;
                        System.out.println("[             Nome               |                  Quantidade                  |           Preço (Unidade)            ] ");
                        for(int l = 0; l < pedido.getItens().size(); l++)
                        {
                            System.out.println("["+pedido.getItens().get(l).getNomeDoProduto()+"\t|\t"+pedido.getItens().get(l).getQuantidadePedida()+"\t|\t"+pedido.getItens().get(l).getPreço()+"\t]");
                        }
                        System.out.println("========================================================================================================================");;
                        System.out.println("[\t\t Total"+"\t|\t"+"Qtd. Total: "+quantidadeTotalDeItensPedidos+"\t|\t"+"Preço: R$"+preçoTotal+"\t|\t"+"Pagamento em: "+pedido.getTipoDePagamento()+"\t\t]");
                        
                    }
                }
                else
                {
                    System.out.println();
                }
            }
        }
        while(!opçãoPedido.toLowerCase().equals("fim"));
        System.out.println("       [                                             Saindo...                                                ]");

        reader.close();
    }
}
