package exercicio7;

public class Produto 
{
    //---------------------------------------------FERRAMENTAS-----------------------------------------------

    //----------------------------------------------ATRIBUTOS------------------------------------------------

        private String nomeDoProduto;
        private double preço;
        private int quantidadeEmEstoque;
        private int quantidadePedida;
        private Boolean existeProdutoNoEstoque;

    //--------------------------------------------CONSTRUTORES-----------------------------------------------
        
        public Produto() 
        {
        }
        public Produto(String nomeDoProduto, double preço, int quantidadeEmEstoque) 
        {
            this.nomeDoProduto = nomeDoProduto;
            this.preço = preço;
            this.quantidadeEmEstoque = quantidadeEmEstoque;
        }

    //-----------------------------------------------MÉTODOS-------------------------------------------------

    //-----------------------------------------GETTER's E SETTER's-------------------------------------------
    
        public String getNomeDoProduto() 
        {
            return nomeDoProduto;
        }
        public double getPreço() 
        {
            return preço;
        }
        public int getQuantidadeEmEstoque() 
        {
            return quantidadeEmEstoque;
        }
        public int getQuantidadePedida() 
        {
            return quantidadePedida;
        }
        public Boolean getExistenciaDoProdutoNoEstoque()
        {
            return existeProdutoNoEstoque;
        }

        public void setNomeDoProduto(String nomeDoProduto) 
        {
            this.nomeDoProduto = nomeDoProduto;
        }
        public void setPreço(double preço) 
        {
            if(preço<0)
            {
                System.out.println("Valor inválido, preço atual do produto cadastrado: $0.00");
                this.preço = 0;
            }
            else
            {
                this.preço = preço;
            }
            
        }
        public void setQuantidadeEmEstoque(int quantidadeEmEstoque) 
        {
            if(quantidadeEmEstoque<0)
            {
                System.out.println("Valor inválido, quantidade atual em estoque do produto cadastrado: 0.");
            }
            else
            {
                this.quantidadeEmEstoque = quantidadeEmEstoque;
            }
        }
        public void setQuantidadePedida(int quantidadePedida) 
        {
            if(quantidadePedida<0)
            {
                this.quantidadePedida = 0;
            }
            else
            {
                this.quantidadePedida = quantidadePedida;
            }
        }
        public void setExistenciaDoProdutoNoEstoque(Boolean existeProdutoNoEstoque)
        {
            this.existeProdutoNoEstoque = existeProdutoNoEstoque;
        }
    
        //--------------------------------------------SOBRESCRIÇÕES----------------------------------------------

}
