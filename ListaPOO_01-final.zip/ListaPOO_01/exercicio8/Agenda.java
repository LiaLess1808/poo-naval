package exercicio8;

import java.util.ArrayList;
import java.util.List;

public class Agenda 
{
    //---------------------------------------------FERRAMENTAS-----------------------------------------------

    //----------------------------------------------ATRIBUTOS------------------------------------------------

        private List<Contato> contatos = new ArrayList<Contato>();

    //--------------------------------------------CONSTRUTORES-----------------------------------------------

        public Agenda() 
        {
        }

    //-----------------------------------------------MÉTODOS-------------------------------------------------

    //-----------------------------------------GETTER's E SETTER's-------------------------------------------

        public List<Contato> getContatos() 
        {
            return contatos;
        }

        public void setContatos(List<Contato> contatos) 
        {
            this.contatos = contatos;
        }

    //--------------------------------------------SOBRESCRIÇÕES----------------------------------------------
        
}
