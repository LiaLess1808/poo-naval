package exercicio8;

public class Contato 
{
    //---------------------------------------------FERRAMENTAS-----------------------------------------------



    //----------------------------------------------ATRIBUTOS------------------------------------------------

        private String numero;
        private String nome;
        private String tipoDeNumero;
        

    //--------------------------------------------CONSTRUTORES-----------------------------------------------

        public Contato() 
        {
        }
        public Contato(String numero, String nome, String tipoDeNumero) {
            this.numero = numero;
            this.nome = nome;
            this.tipoDeNumero = tipoDeNumero;
        }
        
        
    //-----------------------------------------------MÉTODOS-------------------------------------------------

        

    //-----------------------------------------GETTER's E SETTER's-------------------------------------------

        public String getNumero() 
        {
            return numero;
        }
        public String getNome() 
        {
            return nome;
        }
        public String getTipoDeNumero() 
        {
            return tipoDeNumero;
        }


        public void setNumero(String numero) 
        {
            this.numero = numero;
        }
        public void setNome(String nome) 
        {
            this.nome = nome;
        }
        public void setTipoDeNumero(String tipoDeNumero) 
        {
            this.tipoDeNumero = tipoDeNumero;
        }
        
    //--------------------------------------------SOBRESCRIÇÕES----------------------------------------------

}
