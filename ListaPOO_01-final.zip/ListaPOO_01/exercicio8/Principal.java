package exercicio8;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Principal 
{
    public static void main(String args[])
    {
        Scanner reader = new Scanner(System.in);
        
        Contato ctt;
        List<Contato> listaDeContatos = new ArrayList<Contato>();
        Agenda agendaTelefonica = new Agenda();

        agendaTelefonica.setContatos(listaDeContatos);
        String nomeBusca = " ";
        String numeroBusca = " ";
        String tipoBusca = " ";

        String opção = " ";
        
        do
        {
            System.out.println("========================================================================================================================");
            System.out.println("[                                         Escolha uma das opções abaixo                                                ]");
            System.out.println("------------------------------------------------------------------------------------------------------------------------");
            System.out.println("[                                            ADD - Adiciona contatos                                                   ]");
            System.out.println("[                                        RMV - Remove um contado da lista                                              ]");
            System.out.println("[                                           SRCH - Procura um contato                                                  ]");
            System.out.println("[                                  PRNT - Imprime todos os contatos adicionados                                        ]");
            System.out.println("[                                            FIM  - Sair do programa                                                   ]");
            System.out.println("========================================================================================================================");

            System.out.print("        Digite aqui sua opção: ");
                opção = reader.nextLine();
            System.out.println();

            if(opção.equalsIgnoreCase("add"))
            {
                ctt = new Contato();
                    
                System.out.print("Digite seu nome: ");
                    ctt.setNome(reader.nextLine());
                System.out.println();

                System.out.print("Digite seu número ( Formato: (00) 91111-2222 ): ");
                    ctt.setNumero(reader.nextLine());
                System.out.println();

                System.out.print("Digite o seu tipo de contato ( Pessoal ou comercial ): ");
                    ctt.setTipoDeNumero(reader.nextLine());
                System.out.println();
                
                agendaTelefonica.getContatos().add(ctt);
            }
            else
            {
                if(opção.equalsIgnoreCase("rmv"))
                {
                    if(agendaTelefonica.getContatos().isEmpty())
                    {
                        System.out.println("       [                                 Não existem contatos na agenda!                                      ]");
                        System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
                        reader.nextLine();
                    }
                    else
                    {
                        int optCttRmv;
                        int cttsRemovidos = 0;
                        do
                        {
                            if(agendaTelefonica.getContatos().isEmpty())
                            {
                                System.out.println("       [                                 Não existem contatos na agenda!                                      ]");
                                optCttRmv = 0;
                            }
                            else
                            {
                                System.out.println("[     Escolha uma das opções a seguir: ]");
                                System.out.println("[  1 - Remover pelo nome do contato.   ]");
                                System.out.println("[  2 - Remover pelo número do contato. ]");
                                System.out.println("[  3 - Remover pelo tipo do contato.   ]");
                                System.out.println("[              0 - Voltar              ]");

                                System.out.print("\tDigite sua opção: ");
                                optCttRmv = reader.nextInt();
                                reader.nextLine();

                                switch(optCttRmv)
                                {
                                    case 0:
                                    {
                                        System.out.println("[ Voltando... ]");
                                    }
                                    break;

                                    case 1:
                                    {
                                        System.out.print("Digite o nome do contato a ser removido: ");
                                        nomeBusca = reader.nextLine();

                                        for(int l = 0; l < agendaTelefonica.getContatos().size(); l++)
                                        {
                                            if(agendaTelefonica.getContatos().get(l).getNome().toLowerCase().contains(nomeBusca.toLowerCase()))
                                            {
                                                agendaTelefonica.getContatos().remove(agendaTelefonica.getContatos().get(l));
                                                cttsRemovidos++;
                                            }
                                        }
                                        
                                        if(cttsRemovidos != 0)
                                        {
                                            System.out.println("[ Contatos removidos. ]");
                                        }
                                        else
                                        {
                                            System.out.println("[ Nenhum contato foi removido. ]");
                                        }
                                    }
                                    break;

                                    case 2:
                                    {
                                        System.out.print("Digite o número do contato a ser removido (Formato: (00) 91111-2222): ");
                                        numeroBusca = reader.nextLine();

                                        for(int l = 0; l < agendaTelefonica.getContatos().size(); l++)
                                        {
                                            if(agendaTelefonica.getContatos().get(l).getNumero().equalsIgnoreCase(numeroBusca))
                                            {
                                                agendaTelefonica.getContatos().remove(agendaTelefonica.getContatos().get(l));
                                                cttsRemovidos++;
                                            }
                                        }
                                        
                                        if(cttsRemovidos != 0)
                                        {
                                            System.out.println("[ Contatos removidos. ]");
                                        }
                                        else
                                        {
                                            System.out.println("[ Nenhum contato foi removido. ]");
                                        }
                                    }
                                    break;
                                    
                                    case 3:
                                    {
                                        System.out.print("Digite o tipo de contato a ser removido: ");
                                        tipoBusca = reader.nextLine();

                                        for(int l = 0; l < agendaTelefonica.getContatos().size(); l++)
                                        {
                                            if(agendaTelefonica.getContatos().get(l).getTipoDeNumero().equalsIgnoreCase(tipoBusca))
                                            {
                                                agendaTelefonica.getContatos().remove(agendaTelefonica.getContatos().get(l));
                                                cttsRemovidos++;
                                            }
                                        }

                                        if(cttsRemovidos != 0)
                                        {
                                            System.out.println("[ Contatos removidos. ]");
                                        }
                                        else
                                        {
                                            System.out.println("[ Nenhum contato foi removido. ]");
                                        }
                                    }
                                    break;

                                    default: System.out.println("Opção Inválida. Tente novamente.");
                                    
                                }
                            }
                        }
                        while(!(optCttRmv == 0));
                        
                        System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
                        reader.nextLine();
                    }

                    
                }
                else
                {
                    
                    if(opção.equalsIgnoreCase("srch"))
                    {
                        if(agendaTelefonica.getContatos().isEmpty())
                        {
                            System.out.println("       [                                 Não existem contatos na agenda!                                      ]");
                            System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
                            reader.nextLine();
                        }
                        else
                        {
                            int optCttSrch;
                            int cttsEncontrados = 0;
                            do
                            {
                                System.out.println("[     Escolha uma das opções a seguir:  ]");
                                System.out.println("[  1 - Procurar pelo nome do contato.   ]");
                                System.out.println("[  2 - Procurar pelo número do contato. ]");
                                System.out.println("[  3 - Procurar pelo tipo do contato.   ]");
                                System.out.println("[              0 - Voltar               ]");

                                System.out.print("\tDigite sua opção: ");
                                optCttSrch = reader.nextInt();
                                reader.nextLine();

                                switch(optCttSrch)
                                {
                                    case 0:
                                    {
                                        System.out.println("[ Voltando... ]");
                                    }
                                    break;

                                    case 1:
                                    {
                                        System.out.print("Digite um nome: ");
                                        nomeBusca = reader.nextLine();

                                        for(int l = 0; l < agendaTelefonica.getContatos().size(); l++)
                                        {
                                            if(agendaTelefonica.getContatos().get(l).getNome().toLowerCase().contains(nomeBusca.toLowerCase()))
                                            {
                                                cttsEncontrados++;
                                            }
                                        }

                                        if(cttsEncontrados != 0)
                                        {
                                            System.out.println("========================================================================================================================");
                                            System.out.println("[                                   Lista de contatos encontrados a partir da sua busca                                ]");
                                            for(int l = 0; l < agendaTelefonica.getContatos().size(); l++)
                                            {
                                                if(agendaTelefonica.getContatos().get(l).getNome().toLowerCase().contains(nomeBusca.toLowerCase()))
                                                {
                                                    System.out.println("\t[\t"+agendaTelefonica.getContatos().get(l).getNome()+"\t|\t"+ agendaTelefonica.getContatos().get(l).getNumero()+"\t|\t"+agendaTelefonica.getContatos().get(l).getTipoDeNumero()+"\t]");
                                                }
                                            }
                                        }
                                        else
                                        {
                                            System.out.println("[                                                   Nenhum contato foi encontrado na agenda.                                                  ]");
                                        }
                                    }
                                    break;

                                    case 2:
                                    {
                                        System.out.print("Digite um número: ");
                                        numeroBusca = reader.nextLine();

                                        for(int l = 0; l < agendaTelefonica.getContatos().size(); l++)
                                        {
                                            if(agendaTelefonica.getContatos().get(l).getNumero().contains(numeroBusca.toLowerCase()))
                                            {
                                                cttsEncontrados++;
                                            }
                                        }
                                        
                                        if(cttsEncontrados != 0)
                                        {
                                            System.out.println("========================================================================================================================");
                                            System.out.println("[                                   Lista de contatos encontrados a partir da sua busca                                ]");
                                            for(int l = 0; l < agendaTelefonica.getContatos().size(); l++)
                                            {
                                                if(agendaTelefonica.getContatos().get(l).getNumero().toLowerCase().contains(numeroBusca.toLowerCase()))
                                                {
                                                    System.out.println("\t[\t"+agendaTelefonica.getContatos().get(l).getNome()+"\t|\t"+ agendaTelefonica.getContatos().get(l).getNumero()+"\t|\t" + agendaTelefonica.getContatos().get(l).getTipoDeNumero()+"\t]");
                                                }
                                            }
                                    
                                        }
                                        else
                                        {
                                            System.out.println("[                                                   Nenhum contato foi encontrado na agenda.                                                  ]");
                                        }
                                    }
                                    break;
                                    
                                    case 3:
                                    {
                                        System.out.print("Digite um tipo de contato: ");
                                        tipoBusca = reader.nextLine();

                                        for(int l = 0; l < agendaTelefonica.getContatos().size(); l++)
                                        {
                                            if(agendaTelefonica.getContatos().get(l).getTipoDeNumero().contains(tipoBusca.toLowerCase()))
                                            {
                                                cttsEncontrados++;
                                            }
                                        }
                                        
                                        if(cttsEncontrados != 0)
                                        {
                                            System.out.println("========================================================================================================================");
                                            System.out.println("[                                   Lista de contatos encontrados a partir da sua busca                                ]");
                                            for(int l = 0; l < agendaTelefonica.getContatos().size(); l++)
                                            {
                                                if(agendaTelefonica.getContatos().get(l).getTipoDeNumero().toLowerCase().contains(tipoBusca.toLowerCase()))
                                                {
                                                    System.out.println("\t[\t"+agendaTelefonica.getContatos().get(l).getNome()+"\t|\t"+ agendaTelefonica.getContatos().get(l).getNumero()+"\t|\t"+agendaTelefonica.getContatos().get(l).getTipoDeNumero()+"\t]");
                                                }
                                            }
                                        }
                                        else
                                        {
                                            System.out.println("[                                                   Nenhum contato foi encontrado na agenda.                                                  ]");
                                        }
                                    }
                                    break;

                                    default: System.out.println("Opção Inválida. Tente novamente.");
                                }
                            }
                            while(!(optCttSrch == 0));
                            System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
                            reader.nextLine();
                        }
                    }
                    else
                    {
                        if(opção.equalsIgnoreCase("prnt"))
                        {
                            if(agendaTelefonica.getContatos().isEmpty())
                            {
                                System.out.println("       [                                 Não existem contatos na agenda!                                      ]");
                                System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
                                reader.nextLine();
                            }
                            else
                            {
                                System.out.println("========================================================================================================================");
                                System.out.println("[                                                   Lista de Contatos                                                  ]");
                                for(int l = 0; l < agendaTelefonica.getContatos().size(); l++)
                                {
                                    System.out.println("\t[\t"+agendaTelefonica.getContatos().get(l).getNome()+"\t|\t"+ agendaTelefonica.getContatos().get(l).getNumero()+"\t|\t"+agendaTelefonica.getContatos().get(l).getTipoDeNumero()+"\t]");
                                }
                                System.out.println();
                                System.out.println();
                                System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
                                reader.nextLine();
                            }
                        }
                    }
                    System.out.println();
                }
                
            }
        }
        while(!opção.toLowerCase().equals("fim"));
        System.out.println("       [                                             Saindo...                                                ]");

        reader.close();
    }
}
