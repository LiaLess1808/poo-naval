package exercicio9;

public class Emprestimo 
{
    //---------------------------------------------FERRAMENTAS-----------------------------------------------

    //----------------------------------------------ATRIBUTOS------------------------------------------------

        private Livro livro;
        private Pessoa usuario;
        private String codEmprestimo;
        
    //--------------------------------------------CONSTRUTORES-----------------------------------------------
        
        public Emprestimo() 
        {
        }
        public Emprestimo(Pessoa usuario)
        {
            this.usuario = usuario;
        }
        public Emprestimo(Livro livro, Pessoa usuario, String codEmprestimo) 
        {
            this.livro = livro;
            this.usuario = usuario;
            this.codEmprestimo = codEmprestimo;

            this.livro.setEmprestado(true);
        }

    //-----------------------------------------------MÉTODOS-------------------------------------------------

        public void devolverLivro()
        {
            this.livro.notBorrowed();
            this.livro.isReturned();

            System.out.println(livro.getNomeDoLivro() + " devolvido.");
        }

    //-----------------------------------------GETTER's E SETTER's-------------------------------------------

        public Livro getLivro() 
        {
            return livro;
        }
        public Pessoa getUsuario() 
        {
            return usuario;
        }
        public String getCodEmprestimo() 
        {
            return codEmprestimo;
        }

        public void setLivro(Livro livro) 
        {
            this.livro = livro;
        }
        public void setUsuario(Pessoa usuario) 
        {
            this.usuario = usuario;
        }
        public void setCodEmprestimo(String codEmprestimo) 
        {
            this.codEmprestimo = codEmprestimo;
        }
        
    //--------------------------------------------SOBRESCRIÇÕES----------------------------------------------
        @Override
        protected void finalize()
        {
            devolverLivro();
        }
}
