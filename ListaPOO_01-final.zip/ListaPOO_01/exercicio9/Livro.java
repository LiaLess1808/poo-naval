package exercicio9;

public class Livro 
{
    //---------------------------------------------FERRAMENTAS-----------------------------------------------

    //----------------------------------------------ATRIBUTOS------------------------------------------------

        private String nomeDoLivro;
        private String nomeDoAutor;
        private String codigoDoLivro;
        private boolean emprestado;
        private boolean devolvido;
        private boolean lido;

    //--------------------------------------------CONSTRUTORES-----------------------------------------------

        public Livro() 
        {
            this.emprestado = false;
        }
        public Livro(String nomeDoLivro, String nomeDoAutor, String codigoDoLivro) 
        {
            this.nomeDoLivro = nomeDoLivro;
            this.nomeDoAutor = nomeDoAutor;
            this.codigoDoLivro = codigoDoLivro;

            this.emprestado = false;
        }

    //-----------------------------------------------MÉTODOS-------------------------------------------------
        
        public boolean isBorrowed() 
        {
            emprestado = true;
            return emprestado;
        }
        public boolean notBorrowed()
        {
            emprestado = false;
            return emprestado;
        }

        public boolean isReturned()
        {
            devolvido = true;
            return devolvido;
        }
        public boolean notReturned()
        {
            devolvido = false;
            return devolvido;
        }
        
        public boolean wasRead()
        {
            devolvido = true;
            lido = true;
            return lido;
        }
        public boolean notRead()
        {
            lido = false;
            return lido;
        }
    
        //-----------------------------------------GETTER's E SETTER's-------------------------------------------

        public String getNomeDoLivro() 
        {
            return nomeDoLivro;
        }
        public String getNomeDoAutor() 
        {
            return nomeDoAutor;
        }
        public String getCodigoDoLivro() 
        {
            return codigoDoLivro;
        }

        public void setNomeDoLivro(String nomeDoLivro) 
        {
            this.nomeDoLivro = nomeDoLivro;
        }
        public void setEmprestado(boolean estaEmprestado) 
        {
            this.emprestado = estaEmprestado;
        }
        public void setNomeDoAutor(String nomeDoAutor) 
        {
            this.nomeDoAutor = nomeDoAutor;
        }
        public void setCodigoDoLivro(String codigoDoLivro) 
        {
            this.codigoDoLivro = codigoDoLivro;
        }

    //--------------------------------------------SOBRESCRIÇÕES----------------------------------------------
        @Override
        public String toString()
        {
            return "[ " + getCodigoDoLivro()+ " - " + getNomeDoLivro() + " de " + getNomeDoAutor() + " ]";
        }
}
