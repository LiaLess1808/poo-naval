package exercicio9;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Random;

public class Principal 
{
    public static void main(String[] args)
    {
        Scanner reader = new Scanner(System.in);
        Random random = new Random();

        int limiteNumérico = 10000000;

        Pessoa pessoa = new Pessoa();
        Emprestimo emprestimo;
        
        Livro livro;

        List<Livro> biblioteca = new ArrayList<Livro>();
        List<Livro> livrosEmprestados = new ArrayList<Livro>();
        List<Livro> livrosLidos = new ArrayList<Livro>();
        List<Emprestimo> listaDeEmprestimos = new ArrayList<Emprestimo>();

        String livroBusca = " ";
        int livrosEncontrados = 0;
        int quantLivrosEmprestados = 0;
        int quantLivrosLidos = 0;
        
        System.out.print("Digite seu nome: ");
            pessoa.setNome(reader.nextLine());
        System.out.println();

        String menuOpt = " ";
        String brwOpt = " ";
        String rtrnOpt = " ";
        String wasReadOpt = " ";

        do
        {
            System.out.println("========================================================================================================================");
            System.out.println("[                                         Escolha uma das opções abaixo                                                ]");
            System.out.println("------------------------------------------------------------------------------------------------------------------------");
            System.out.println("[                                            ADD - Adiciona um livro                                                   ]");
            System.out.println("[                                        BRW - Pegar um livro emprestado                                               ]");
            System.out.println("[                                           RTRN - Devolver um livro                                                   ]");
            System.out.println("[                                 VRFY - Verifica se seus livros foram devolvidos                                      ]");
            System.out.println("[                                 PRNT - Imprime todos os livros que o usuário leu                                     ]");
            System.out.println("[                                            FIM  - Sair do programa                                                   ]");
            System.out.println("========================================================================================================================");
            System.out.println();

            System.out.print("Digite sua opção: ");
                menuOpt = reader.nextLine();
            System.out.println();

            if(menuOpt.equalsIgnoreCase("add"))
            {
                
                livro = new Livro();
                    livro.notBorrowed();
                    livro.notRead();
                
                    
                System.out.print("Digite o nome do livro emprestado: ");
                    livro.setNomeDoLivro(reader.nextLine());
                System.out.println();

                System.out.print("Digite o nome do autor do livro emprestado: ");
                    livro.setNomeDoAutor(reader.nextLine());
                System.out.println();

                System.out.print("Digite o código do livro emprestado: ");
                    livro.setCodigoDoLivro(reader.nextLine());
                System.out.println();
                
                biblioteca.add(livro);    
            }
            else
            {
                if(menuOpt.equalsIgnoreCase("brw"))
                {
                    if(biblioteca.isEmpty())
                    {
                        System.out.println("       [                                Não existem livros na biblioteca!                                     ]");
                        System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
                        reader.nextLine();
                    }
                    else
                    {
                        
                        System.out.print("Digite o nome do livro que deseja procurar: ");
                        livroBusca = reader.nextLine();
                        System.out.println();

                        System.out.println("[ Livros correspondentes a sua busca ]");
                        for(int l = 0; l < biblioteca.size(); l++)
                        {
                            if(biblioteca.get(l).getNomeDoLivro().toLowerCase().contains(livroBusca.toLowerCase()))
                            {
                                livrosEncontrados++;

                                System.out.println("[ " + biblioteca.get(l).getNomeDoLivro()+"\t|\t"+biblioteca.get(l).getNomeDoAutor()+"\t|\t"+biblioteca.get(l).getCodigoDoLivro()+" ]");
                                System.out.println();

                                System.out.println("Adicionar esse item: ");
                                brwOpt = reader.nextLine();

                                if(brwOpt.toLowerCase().contains("si")||brwOpt.toLowerCase().contains("ye"))
                                {
                                    biblioteca.get(l).isBorrowed();

                                    if(biblioteca.get(l).isBorrowed())
                                    {
                                        livrosEmprestados.add(biblioteca.get(l));
                                        quantLivrosEmprestados++;
                                        System.out.println(biblioteca.get(l).getNomeDoLivro() + " emprestado com sucesso.");

                                        for(int c = 0; c < livrosEmprestados.size();c++)
                                        {
                                            emprestimo = new Emprestimo(livrosEmprestados.get(c), pessoa, String.valueOf(random.nextInt(limiteNumérico)));

                                            listaDeEmprestimos.add(emprestimo);
                                        }
                                    }
                                }
                                else
                                {
                                    continue;
                                }
                            }
                            else
                            {
                                continue;
                            }
                        }
                        System.out.println();

                        if(livrosEncontrados == 0)
                        {
                            System.out.println("[                                                   Nenhum livro correspondente encontrado.                                                  ]");
                        }
                        else
                        {
                            if(quantLivrosEmprestados == 0)
                            {
                                System.out.println("[                                                         Nenhum livro foi emprestado.                                                       ]");
                            }
                        }
                    }
                }
                else
                {   
                    if(menuOpt.equalsIgnoreCase("rtrn"))
                    {
                        if(biblioteca.isEmpty())
                        {
                            System.out.println("       [                                Não existem livros na biblioteca!                                     ]");
                            System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
                            reader.nextLine();
                        }
                        else
                        {
                            if(quantLivrosEmprestados == 0)
                            {
                                System.out.println("[                                                         Nenhum livro foi emprestado.                                                       ]");
                            }
                            else
                            {
                                System.out.print("Digite o nome do livro que deseja procurar: ");
                                livroBusca = reader.nextLine();
                                System.out.println();

                                for(int l = 0; l < listaDeEmprestimos.size();l++)
                                {
                                    if(listaDeEmprestimos.get(l).getLivro().getNomeDoLivro().toLowerCase().contains(livroBusca.toLowerCase()))
                                    {
                                        System.out.println(" - " + listaDeEmprestimos.get(l).getLivro().getNomeDoLivro());
                                        System.out.print("Digite sim para devolver este livro: ");
                                            rtrnOpt = reader.nextLine();
                                        System.out.println();

                                        if(rtrnOpt.toLowerCase().contains("si")||rtrnOpt.toLowerCase().contains("ye"))
                                        {
                                            listaDeEmprestimos.get(l).devolverLivro();
                                            System.out.println();

                                            System.out.println("Digite sim caso tenha terminado de ler o livro: ");
                                                wasReadOpt = reader.nextLine();
                                            System.out.println();

                                            if(wasReadOpt.toLowerCase().contains("si")||wasReadOpt.toLowerCase().contains("ye"))
                                            {
                                                livrosLidos.add(listaDeEmprestimos.get(l).getLivro());
                                                quantLivrosLidos++;
                                                System.out.println("[ Livro adicionado à lista de livros lidos. ]");
                                                
                                                for(int c = 0; c < livrosEmprestados.size(); c++)
                                                {
                                                    if(listaDeEmprestimos.get(l).getLivro().getNomeDoLivro().toLowerCase().equals(livrosEmprestados.get(c).getNomeDoLivro().toLowerCase()))
                                                    {
                                                        livrosEmprestados.remove(livrosEmprestados.get(c));
                                                    }
                                                }
                                                listaDeEmprestimos.remove(listaDeEmprestimos.get(l));
                                            }
                                        }
                                        else
                                        {
                                            System.out.println("[ Livro ainda em uso. ]");
                                        }
                                    }
                                }
                            }

                            
                        }
                    }
                    else
                    {
                        if(menuOpt.equalsIgnoreCase("vrfy"))
                        {
                            if(biblioteca.isEmpty())
                            {
                                System.out.println("       [                                Não existem livros na biblioteca!                                     ]");
                                System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
                                reader.nextLine();
                            }
                            else
                            {

                                System.out.println("========================================================================================================================");
                                System.out.println("[                                               Livros a devolver                                                      ]");
                                
                                for(int l = 0; l < livrosEmprestados.size();l++)
                                {
                                    if(livrosEmprestados.get(l).isBorrowed())
                                    {
                                        quantLivrosEmprestados++;
                                        System.out.println(livrosEmprestados.get(l).toString());
                                    }
                                    else
                                    {
                                        continue;
                                    }
                                }
                                if(quantLivrosEmprestados == 0)
                                {
                                    System.out.println("[ Nenhum livro para devolver. ]");
                                } 
                            }
                        }
                        else
                        {
                            if(menuOpt.equalsIgnoreCase("prnt"))
                            {
                                
                                if(biblioteca.isEmpty())
                                {
                                    System.out.println("       [                                Não existem livros na biblioteca!                                     ]");
                                    System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
                                    reader.nextLine();
                                }
                                else
                                {
                                    if(quantLivrosLidos == 0)
                                    {
                                        System.out.println("[                                                         Nenhum livro foi lido.                                                       ]");
                                    }
                                    else
                                    {
                                        System.out.println("========================================================================================================================");
                                        System.out.println("[                                                 Livros lidos                                                         ]");
                                        for(int l = 0; l < livrosLidos.size(); l++)
                                        {
                                            System.out.println(livrosLidos.get(l).toString());
                                        }
                                    }
                                }
                            }
                            else
                            {
                                System.out.println();
                            }
                        }
                    }
                }
            }
            System.out.println("       [                               Pressione uma tecla para continuar.                                    ]");
            reader.nextLine();

        }
        while(!menuOpt.equalsIgnoreCase("fim"));

        System.out.println("       [                                             Saindo...                                                ]");

        reader.close();
    }
}
